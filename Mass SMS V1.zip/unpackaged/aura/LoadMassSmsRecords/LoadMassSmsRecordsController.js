({    
    init : function(component, event, helper) {
        //var today = $A.localizationService.formatDate(now, "MMMM dd yyyy, hh:mm:ss a");
        //component.set('v.today', now);
        //var datelocal = moment(new Date(), "DDMMYYYY").add('15', 'minutes');
        //var startDateTime = datelocal.toISOString();
        //component.set("v.todayDt", startDateTime);
    },
    
    CreateRecord: function (component, event, helper) {
        component.set("v.Spinner", true); 
        component.set('v.fileMsg', false);
        component.set('v.SchErrMsg', '');
        var fileInput = component.find("file").getElement();
        var file = fileInput.files[0];
        //var fileInput = event.getSource().get("v.files");
        //var file = fileInput[0];
        console.log('file=='+file);
        if (file && file.name.endsWith(".csv")){
            
            var reader = new FileReader();
            reader.readAsText(file, "UTF-8");
            reader.onload = function (evt) {
                
                //console.log("EVT FN");
                var csv = evt.target.result;
                //console.log('csv file contains'+ csv);
                var result = helper.CSV2JSON(component,csv);	
                //console.log('result = ' + result);
                //console.log('Result = '+JSON.parse(result));
                helper.CreateAccount(component,result);
                component.set("v.Spinner", false); 
                
            }
            reader.onerror = function (evt) {
                console.log("error reading file");
            }
        }
        else{
            component.set("v.Spinner", false); 
            component.set('v.fileMsg',true);
        } 
        
    },
    
    clearData :  function (component, event, helper){ 
        //component.set('v.showSpinner', true);
        console.log('Start');
        component.set('v.fileMsg', false);
        component.set('v.schMsg', false);
        component.set('v.isSchSuccess', false);
        component.set('v.SchErrMsg', '');
        
        try{
            component.find('file').getElement().value='';   
            component.find("today").set("v.value",'');  
            component.set('v.wrapperList', null);
        }
        catch(err){
            console.log(err);
        }
        
        component.set('v.showSpinner', false);
    },
    
    scheduleSms :  function (component, event, helper){ 
        component.set('v.fileMsg',false); 
        component.set('v.schMsg', false);
        component.set('v.SchErrMsg', '');
        var todayVal = component.find("today").get("v.value");
        console.log('todayVal=='+todayVal);
        
        var isDateError = component.get("v.dateValidationError");
        
        if(isDateError == true){
            alert('Date must be in present or in future..');
        }
        else{    
            if(todayVal != null){
                try{
                    helper.scheduleCallHelper(component);    
                }
                catch(err){
                    console.log(err);   
                }    
            }
            else{
                component.set('v.schMsg', true);
            }
        }
        
    },   
    
    // this function automatic call by aura:waiting event  
    showSpinner: function(component, event, helper) {
       // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true); 
   },
    
 // this function automatic call by aura:doneWaiting event 
    hideSpinner : function(component,event,helper){
     // make Spinner attribute to false for hide loading spinner    
       component.set("v.Spinner", false);
    },
    
   dateUpdate : function(component, event, helper) {
        component.set("v.dateValidationError" , false);
        var today = new Date();        
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();
     // if date is less then 10, then append 0 before date   
        if(dd < 10){
            dd = '0' + dd;
        } 
    // if month is less then 10, then append 0 before date    
        if(mm < 10){
            mm = '0' + mm;
        }
        
     var todayFormattedDate = yyyy+'-'+mm+'-'+dd;
        if(component.get("v.todayDt") != '' && component.get("v.todayDt") < todayFormattedDate){
            component.set("v.dateValidationError" , true);
        }else{
            component.set("v.dateValidationError" , false);
        }
    },   
})